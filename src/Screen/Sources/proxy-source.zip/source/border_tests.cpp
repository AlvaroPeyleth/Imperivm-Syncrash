#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include "border_geometry.h"

static bool Check(RECT monitor, RECT game, int expected)
{
    RECT strips[4] = {};
    int count = BorderRectangles(monitor, game, strips);
    if (count != expected) return false;
    LONGLONG area = 0;
    for (int i = 0; i < count; ++i) {
        const RECT &r = strips[i];
        if (r.left < monitor.left || r.top < monitor.top || r.right > monitor.right || r.bottom > monitor.bottom) return false;
        RECT overlap;
        if (IntersectRect(&overlap, &r, &game)) return false;
        for (int j = 0; j < i; ++j) if (IntersectRect(&overlap, &r, &strips[j])) return false;
        area += static_cast<LONGLONG>(r.right-r.left) * (r.bottom-r.top);
    }
    RECT intersection;
    if (IntersectRect(&intersection, &monitor, &game))
        return area == static_cast<LONGLONG>(monitor.right-monitor.left)*(monitor.bottom-monitor.top) -
            static_cast<LONGLONG>(intersection.right-intersection.left)*(intersection.bottom-intersection.top);
    return count == 0;
}
int main()
{
    if (!Check({0,0,3440,1440},{440,0,3000,1440},2) ||
        !Check({0,0,1920,1080},{0,0,1920,1080},0) ||
        !Check({0,0,1920,1200},{0,60,1920,1140},2) ||
        !Check({0,0,1366,768},{0,0,1365,768},1) ||
        !Check({0,0,3440,1440},{440,100,3000,1300},4) ||
        !Check({0,0,3440,1440},{-200,-100,3000,1300},2) ||
        !Check({0,0,3440,1440},{-2560,-255,0,1185},0) ||
        !Check({-2560,-255,0,1185},{-2240,-255,-320,1185},2) ||
        !Check({0,0,1920,1080},{-50,-50,2000,1200},0)) return 1;
    RECT out[4];
    if (BorderRectangles({0,0,0,1080},{0,0,100,100},out) ||
        BorderRectangles({0,0,1920,1080},{50,50,25,25},out) ||
        BorderRectangles({0,0,1920,1080},{0,0,100,100},NULL)) return 1;
    puts("PASS 9 black-margin layouts, disjoint coverage and invalid inputs");
    return 0;
}
