// Syncrash local experiment. Integer geometry; no display-changing APIs.
#pragma once
#include <limits.h>

struct ScreenPlacement { int x, y, width, height; };

inline bool Fit1080(int left, int top, int width, int height, ScreenPlacement *out)
{
    if (!out || width <= 0 || height <= 0 || width > SHRT_MAX || height > SHRT_MAX)
        return false;
    // Largest 16:9 rectangle that fits, with at most one pixel of rounding.
    int w = width, h = height;
    if (static_cast<long long>(width) * 1080 <= static_cast<long long>(height) * 1920)
        h = static_cast<int>(static_cast<long long>(width) * 1080 / 1920);
    else
        w = static_cast<int>(static_cast<long long>(height) * 1920 / 1080);
    long long x = static_cast<long long>(left) + (width - w) / 2;
    long long y = static_cast<long long>(top) + (height - h) / 2;
    // DxWnd TARGETMAP stores placement in signed shorts.
    if (w <= 0 || h <= 0 || x < SHRT_MIN || x > SHRT_MAX || y < SHRT_MIN || y > SHRT_MAX)
        return false;
    out->x = static_cast<int>(x); out->y = static_cast<int>(y);
    out->width = w; out->height = h;
    return true;
}
