#pragma once
#include <windows.h>

// Four disjoint strips around the visible part of the game, inside one monitor.
// A game outside this monitor must never cause a full-screen black cover.
inline int BorderRectangles(const RECT &monitor, const RECT &game, RECT output[4])
{
    if (!output || monitor.right <= monitor.left || monitor.bottom <= monitor.top ||
        game.right <= game.left || game.bottom <= game.top) return 0;
    RECT visible = { max(monitor.left, game.left), max(monitor.top, game.top),
                     min(monitor.right, game.right), min(monitor.bottom, game.bottom) };
    if (visible.right <= visible.left || visible.bottom <= visible.top) return 0;
    RECT strips[4] = {
        {monitor.left, monitor.top, visible.left, monitor.bottom},
        {visible.right, monitor.top, monitor.right, monitor.bottom},
        {visible.left, monitor.top, visible.right, visible.top},
        {visible.left, visible.bottom, visible.right, monitor.bottom}
    };
    int count = 0;
    for (int i = 0; i < 4; ++i)
        if (strips[i].right > strips[i].left && strips[i].bottom > strips[i].top)
            output[count++] = strips[i];
    return count;
}
