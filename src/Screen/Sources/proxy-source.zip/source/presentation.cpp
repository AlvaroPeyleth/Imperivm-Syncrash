// Syncrash local presentation experiment, 2026-09-26.
// Uses the shell's per-window fullscreen hint, not global taskbar settings.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shobjidl.h>
#include <stdio.h>
#include "dxwnd.h"

typedef DXWNDSTATUS *(*GetHookInfoProc)();
static LONG started = 0;
void RunBlackBorders(HWND game);

static DWORD WINAPI MarkGameFullscreen(LPVOID context)
{
    GetHookInfoProc getInfo = reinterpret_cast<GetHookInfoProc>(context);
    HRESULT initialized = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
    HRESULT result = initialized;
    ITaskbarList2 *taskbar = NULL;
    HWND marked = NULL;
    if (SUCCEEDED(initialized)) {
        result = CoCreateInstance(CLSID_TaskbarList, NULL, CLSCTX_INPROC_SERVER,
                                  IID_ITaskbarList2, reinterpret_cast<void **>(&taskbar));
        if (SUCCEEDED(result)) result = taskbar->HrInit();
        // Wait outside loader lock for DxWnd to identify the game's main window.
        // This is a bounded startup trial, not support for later window recreation.
        if (SUCCEEDED(result)) {
            result = HRESULT_FROM_WIN32(ERROR_TIMEOUT);
            for (int attempt = 0; attempt < 300; ++attempt) {
                DXWNDSTATUS *info = getInfo();
                HWND window = info ? info->hWnd : NULL;
                DWORD owner = 0;
                if (window) GetWindowThreadProcessId(window, &owner);
                if (owner == GetCurrentProcessId() && IsWindowVisible(window)) {
                    result = taskbar->MarkFullscreenWindow(window, TRUE);
                    if (SUCCEEDED(result)) { marked = window; break; }
                }
                Sleep(200);
            }
        }
        if (taskbar) taskbar->Release();
        CoUninitialize();
    }
    FILE *report = NULL;
    if (fopen_s(&report, "syncrash-screen-trial.log", "a") == 0 && report) {
        fprintf(report, "Fullscreen hint: pid=%lu hwnd=%p HRESULT=0x%08lX\n",
                GetCurrentProcessId(), marked, static_cast<unsigned long>(result));
        fclose(report);
    }
    if (marked) RunBlackBorders(marked);
    return 0;
}

void StartPresentationTrial(HMODULE dxwnd)
{
    if (!GetPrivateProfileIntA("syncrash", "markfullscreen", 0, ".\\dxwnd.dxw")) return;
    GetHookInfoProc getInfo = reinterpret_cast<GetHookInfoProc>(GetProcAddress(dxwnd, "GetHookInfo"));
    if (!getInfo || InterlockedExchange(&started, 1)) return;
    // The worker starts after loader initialization; no COM calls or waits in DllMain.
    HANDLE worker = CreateThread(NULL, 0, MarkGameFullscreen, reinterpret_cast<LPVOID>(getInfo), 0, NULL);
    if (worker) CloseHandle(worker);
}
