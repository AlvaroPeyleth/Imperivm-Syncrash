// Local Syncrash/DxWnd proxy experiment. Black margins do not change display modes.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include "border_geometry.h"

// Capture physical, unhooked entry points before DxWnd rewrites imports.
#define REAL_API(name) static decltype(&name) real##name;
REAL_API(RegisterClassExW)
REAL_API(UnregisterClassW)
REAL_API(CreateWindowExW)
REAL_API(DestroyWindow)
REAL_API(DefWindowProcW)
REAL_API(SetWindowPos)
REAL_API(ShowWindow)
REAL_API(GetWindowRect)
REAL_API(GetForegroundWindow)
REAL_API(GetWindowThreadProcessId)
REAL_API(IsWindowVisible)
REAL_API(IsIconic)
REAL_API(IsWindow)
REAL_API(SetWinEventHook)
REAL_API(UnhookWinEvent)
REAL_API(SetTimer)
REAL_API(KillTimer)
REAL_API(GetMessageW)
REAL_API(DispatchMessageW)
REAL_API(PostQuitMessage)
#undef REAL_API

static RECT primary;
static HWND gameWindow;
static HWND borders[4];
static RECT previous[4];
static bool shown[4];
static bool ready;
static HBRUSH blackBrush;
static const wchar_t className[] = L"SyncrashLocalBlackMargins";

void PrepareBlackBorders(const RECT &monitor)
{
    primary = monitor;
    HMODULE user32 = GetModuleHandleW(L"user32.dll");
    ready = true;
#define LOAD_API(name) real##name = reinterpret_cast<decltype(&name)>(GetProcAddress(user32, #name)); ready = ready && real##name != NULL;
    LOAD_API(RegisterClassExW) LOAD_API(UnregisterClassW)
    LOAD_API(CreateWindowExW) LOAD_API(DestroyWindow) LOAD_API(DefWindowProcW)
    LOAD_API(SetWindowPos) LOAD_API(ShowWindow) LOAD_API(GetWindowRect)
    LOAD_API(GetForegroundWindow) LOAD_API(GetWindowThreadProcessId)
    LOAD_API(IsWindowVisible) LOAD_API(IsIconic) LOAD_API(IsWindow)
    LOAD_API(SetWinEventHook) LOAD_API(UnhookWinEvent)
    LOAD_API(SetTimer) LOAD_API(KillTimer) LOAD_API(GetMessageW)
    LOAD_API(DispatchMessageW) LOAD_API(PostQuitMessage)
#undef LOAD_API
    blackBrush = static_cast<HBRUSH>(GetStockObject(BLACK_BRUSH));
    ready = ready && blackBrush != NULL;
}

static void HideBorders()
{
    for (int i = 0; i < 4; ++i) {
        if (shown[i]) realShowWindow(borders[i], SW_HIDE);
        shown[i] = false;
    }
}

static void UpdateBorders()
{
    if (!realIsWindow(gameWindow)) {
        HideBorders();
        realPostQuitMessage(0);
        return;
    }
    DWORD owner = 0;
    realGetWindowThreadProcessId(realGetForegroundWindow(), &owner);
    RECT game = {};
    if (owner != GetCurrentProcessId() || !realIsWindowVisible(gameWindow) ||
        realIsIconic(gameWindow) || !realGetWindowRect(gameWindow, &game)) {
        HideBorders();
        return;
    }
    RECT strips[4] = {};
    int count = BorderRectangles(primary, game, strips);
    for (int i = 0; i < 4; ++i) {
        if (i >= count) {
            if (shown[i]) realShowWindow(borders[i], SW_HIDE);
            shown[i] = false;
        } else if (!shown[i] || !EqualRect(&previous[i], &strips[i])) {
            const RECT &r = strips[i];
            // Regular z-order, never TOPMOST; no activation and no overlap with the game.
            if (realSetWindowPos(borders[i], HWND_TOP, r.left, r.top,
                                 r.right-r.left, r.bottom-r.top, SWP_NOACTIVATE | SWP_SHOWWINDOW)) {
                previous[i] = r;
                shown[i] = true;
            }
        }
    }
}

static LRESULT CALLBACK BorderProc(HWND window, UINT message, WPARAM wparam, LPARAM lparam)
{
    if (message == WM_MOUSEACTIVATE) return MA_NOACTIVATE;
    if (message == WM_CLOSE) return 0;
    return realDefWindowProcW(window, message, wparam, lparam);
}

static void CALLBACK WindowEvent(HWINEVENTHOOK, DWORD event, HWND window, LONG object, LONG child, DWORD, DWORD)
{
    if (event == EVENT_SYSTEM_FOREGROUND ||
        (window == gameWindow && object == OBJID_WINDOW && child == CHILDID_SELF))
        UpdateBorders();
}

void RunBlackBorders(HWND game)
{
    if (!ready || !game) return;
    gameWindow = game;
    HINSTANCE instance = GetModuleHandleW(NULL);
    WNDCLASSEXW wc = {};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = BorderProc;
    wc.hInstance = instance;
    wc.hbrBackground = blackBrush;
    wc.lpszClassName = className;
    if (!realRegisterClassExW(&wc)) return;
    bool created = true;
    for (int i = 0; i < 4; ++i) {
        borders[i] = realCreateWindowExW(WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE,
            className, L"", WS_POPUP, 0, 0, 0, 0, NULL, NULL, instance, NULL);
        created = created && borders[i] != NULL;
    }
    HWINEVENTHOOK focus = NULL, geometry = NULL;
    UINT_PTR timer = 0;
    if (created) {
        focus = realSetWinEventHook(EVENT_SYSTEM_FOREGROUND, EVENT_SYSTEM_FOREGROUND,
            NULL, WindowEvent, 0, 0, WINEVENT_OUTOFCONTEXT);
        geometry = realSetWinEventHook(EVENT_OBJECT_DESTROY, EVENT_OBJECT_LOCATIONCHANGE,
            NULL, WindowEvent, GetCurrentProcessId(), 0, WINEVENT_OUTOFCONTEXT);
        // Also recover if an event is missed; no rendering or mouse polling.
        timer = realSetTimer(NULL, 0, 1000, NULL);
    }
    FILE *report = NULL;
    if (fopen_s(&report, "syncrash-screen-trial.log", "a") == 0 && report) {
        fprintf(report, "Black margins: pid=%lu ready=%d monitor=%ld,%ld,%ld,%ld\n",
            GetCurrentProcessId(), created && focus && geometry && timer,
            primary.left, primary.top, primary.right, primary.bottom);
        fclose(report);
    }
    // Without focus events, fail open rather than leaving covers over the desktop.
    if (created && focus && geometry && timer) {
        UpdateBorders();
        MSG message = {};
        while (realGetMessageW(&message, NULL, 0, 0) > 0) {
            if (message.message == WM_TIMER && !message.hwnd && message.wParam == timer)
                UpdateBorders();
            else realDispatchMessageW(&message);
        }
    }
    if (focus) realUnhookWinEvent(focus);
    if (geometry) realUnhookWinEvent(geometry);
    if (timer) realKillTimer(NULL, timer);
    HideBorders();
    for (int i = 0; i < 4; ++i) if (borders[i]) realDestroyWindow(borders[i]);
    realUnregisterClassW(className, instance);
}
