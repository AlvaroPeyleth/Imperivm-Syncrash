// Syncrash local experiment: choose the Windows primary display each launch.
// This changes only the game's DPI awareness and virtual window placement.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include "screen_geometry.h"
#include "dxwnd.h"
void PrepareBlackBorders(const RECT &monitor);

struct PrimaryDisplay {
    bool found;
    bool valid;
    RECT pixels;
    char device[CCHDEVICENAME];
};

static BOOL CALLBACK FindPrimary(HMONITOR monitor, HDC, LPRECT, LPARAM context)
{
    MONITORINFOEXA info = {};
    info.cbSize = sizeof(info);
    if (!GetMonitorInfoA(monitor, &info) || !(info.dwFlags & MONITORINFOF_PRIMARY))
        return TRUE;
    PrimaryDisplay *display = reinterpret_cast<PrimaryDisplay *>(context);
    display->found = true;
    DEVMODEA mode = {};
    mode.dmSize = sizeof(mode);
    // EnumDisplaySettingsEx returns physical pixels, irrespective of DPI virtualization.
    if (!EnumDisplaySettingsExA(info.szDevice, ENUM_CURRENT_SETTINGS, &mode, 0)) return FALSE;
    const DWORD required = DM_POSITION | DM_PELSWIDTH | DM_PELSHEIGHT;
    if ((mode.dmFields & required) != required || !mode.dmPelsWidth || !mode.dmPelsHeight ||
        mode.dmPelsWidth > SHRT_MAX || mode.dmPelsHeight > SHRT_MAX) return FALSE;
    // Windows defines the primary monitor's origin as (0,0).
    if (mode.dmPosition.x != 0 || mode.dmPosition.y != 0) return FALSE;
    display->pixels.left = mode.dmPosition.x;
    display->pixels.top = mode.dmPosition.y;
    display->pixels.right = static_cast<LONG>(mode.dmPelsWidth);
    display->pixels.bottom = static_cast<LONG>(mode.dmPelsHeight);
    strcpy_s(display->device, info.szDevice);
    display->valid = true;
    return FALSE;
}

bool ConfigureAdaptiveScreen(TARGETMAP *target)
{
    if (!target) return false;
    // Run before loading DxWnd, so all detection uses the real User32 functions.
    // Preserve an existing aware mode (including the game's compatibility settings).
    if (!IsProcessDPIAware()) {
        SetProcessDPIAware();
        if (!IsProcessDPIAware()) return false;
    }
    PrimaryDisplay primary = {};
    EnumDisplayMonitors(NULL, NULL, FindPrimary, reinterpret_cast<LPARAM>(&primary));
    if (!primary.found || !primary.valid) return false;
    ScreenPlacement fit = {};
    if (!Fit1080(primary.pixels.left, primary.pixels.top,
                 primary.pixels.right - primary.pixels.left,
                 primary.pixels.bottom - primary.pixels.top, &fit)) return false;
    target->posx = static_cast<short>(fit.x); target->posy = static_cast<short>(fit.y);
    target->sizx = static_cast<short>(fit.width); target->sizy = static_cast<short>(fit.height);
    target->resw = 1920; target->resh = 1080;
    target->coordinates = 0; // Absolute geometry, not an enumeration index.
    PrepareBlackBorders(primary.pixels);
    FILE *report = NULL;
    if (fopen_s(&report, "syncrash-screen-trial.log", "a") == 0 && report) {
        fprintf(report, "Adaptive primary: pid=%lu device=%s desktop=%ldx%ld output=%dx%d position=%d,%d internal=1920x1080 dpiAware=%d\n",
                GetCurrentProcessId(), primary.device, primary.pixels.right, primary.pixels.bottom,
                fit.width, fit.height, fit.x, fit.y, IsProcessDPIAware());
        fclose(report);
    }
    return true;
}
