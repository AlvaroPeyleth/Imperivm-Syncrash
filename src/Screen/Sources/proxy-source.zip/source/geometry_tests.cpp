#include <stdio.h>
#include <stdlib.h>
#include "screen_geometry.h"

static int count = 0;
static void Check(int x, int y, int w, int h, int ex, int ey, int ew, int eh)
{
    ScreenPlacement r = {};
    if (!Fit1080(x,y,w,h,&r) || r.x != ex || r.y != ey || r.width != ew || r.height != eh) {
        fprintf(stderr,"FAIL %dx%d at %d,%d\n",w,h,x,y); exit(1);
    }
    ++count;
}
int main()
{
    Check(0,0,1920,1080,0,0,1920,1080);
    Check(0,0,3440,1440,440,0,2560,1440);
    Check(0,0,1920,1200,0,60,1920,1080);
    Check(0,0,2560,1080,320,0,1920,1080);
    Check(0,0,1366,768,0,0,1365,768);
    Check(0,0,1280,720,0,0,1280,720);
    Check(0,0,1280,1024,0,152,1280,720);
    Check(0,0,1080,1920,0,656,1080,607);
    Check(-2560,-255,2560,1440,-2560,-255,2560,1440);
    ScreenPlacement r = {1,2,3,4};
    if (Fit1080(0,0,0,1080,&r) || Fit1080(0,0,1920,-1,&r) ||
        Fit1080(INT_MAX,0,1920,1080,&r) || Fit1080(INT_MIN,0,1920,1080,&r) ||
        Fit1080(0,0,40000,30000,&r) || Fit1080(0,0,1,1,&r) || Fit1080(0,0,1920,1080,NULL) ||
        r.x!=1 || r.y!=2 || r.width!=3 || r.height!=4) return 1;
    printf("PASS %d monitor geometries and invalid/overflow inputs\n",count);
    return 0;
}
