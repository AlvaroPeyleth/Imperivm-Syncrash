#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include "dxwnd.h"
bool ConfigureAdaptiveScreen(TARGETMAP *);
int main()
{
    TARGETMAP target = {};
    if (!ConfigureAdaptiveScreen(&target)) { fprintf(stderr,"Primary display detection failed\n"); return 1; }
    printf("Primary output: %dx%d at %d,%d; internal: %dx%d\n",target.sizx,target.sizy,target.posx,target.posy,target.resw,target.resh);
    return 0;
}
