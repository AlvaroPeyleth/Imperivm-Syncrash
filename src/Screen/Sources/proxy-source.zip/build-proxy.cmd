@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars32.bat"
if errorlevel 1 exit /b 1
cd /d "%~dp0build"
cl /nologo /MT /O2 /W4 /WX /I"..\source" "..\source\geometry_tests.cpp" /Fe:geometry_tests.exe
if errorlevel 1 exit /b 1
geometry_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /MT /O2 /W4 /WX /I"..\source" "..\source\border_tests.cpp" /Fe:border_tests.exe /link user32.lib
if errorlevel 1 exit /b 1
border_tests.exe
if errorlevel 1 exit /b 1
cl /nologo /MT /O2 /W4 /WX /D_CRT_SECURE_NO_WARNINGS /I"..\source" "..\source\display_probe.cpp" "..\source\adaptive_screen.cpp" "..\source\black_borders.cpp" /Fe:display_probe.exe /link user32.lib gdi32.lib
if errorlevel 1 exit /b 1
display_probe.exe
if errorlevel 1 exit /b 1
cl /nologo /LD /MT /O2 /W3 /DWIN32 /D_WINDOWS /D_CRT_SECURE_NO_WARNINGS /I"..\source" "..\source\winmm.cpp" "..\source\init.cpp" "..\source\presentation.cpp" "..\source\adaptive_screen.cpp" "..\source\black_borders.cpp" /link /DEF:"..\source\winmm.def" /OUT:winmm.dll /MACHINE:X86 /DYNAMICBASE /NXCOMPAT user32.lib gdi32.lib ole32.lib uuid.lib
exit /b %errorlevel%