@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars32.bat"
if errorlevel 1 exit /b 1
cd /d "%~dp0source\dll"
if not exist syncrash-build mkdir syncrash-build
if /I "%1"=="link" goto resource
cl /nologo /c /MP4 /MT /O2 /W0 /EHa /Zc:strictStrings- /DDIDFT_OPTIONAL=0x80000000 /DWIN32 /DNDEBUG /D_WINDOWS /D_USRDLL /DDXWND_EXPORTS /D_CRT_SECURE_NO_WARNINGS /I. /I"%WindowsSdkDir%Include\%WindowsSDKVersion%um" /I"%WindowsSdkDir%Include\%WindowsSDKVersion%shared" /I..\Include /Fosyncrash-build\ @syncrash-sources.rsp
if errorlevel 1 exit /b 1
:resource
rc /nologo /dNDEBUG /fosyncrash-build\dxwnd.res dxwnd.rc
if errorlevel 1 exit /b 1
link /nologo /DLL /OUT:syncrash-build\dxwnd.dll /DEF:dxwnd.def /MACHINE:X86 /DYNAMICBASE /NXCOMPAT syncrash-build\*.obj syncrash-build\dxwnd.res libMinHook.x86.lib detours.lib dinput.lib kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib opengl32.lib msimg32.lib xinput.lib version.lib winmm.lib shlwapi.lib comctl32.lib legacy_stdio_definitions.lib
exit /b %errorlevel%