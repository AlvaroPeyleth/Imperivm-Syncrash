#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include "source/dll/syncrash_surface.h"

static void Check(bool condition, const char *message) {
    if (!condition) { fprintf(stderr, "FAIL %s\n", message); ExitProcess(1); }
}
int main() {
    DWORD handles = GetGuiResources(GetCurrentProcess(), GR_GDIOBJECTS);
    HDC device = GetDC(NULL);
    SyncrashSurface source, output;
    Check(source.Ensure(NULL, device, 1920, 1080), "source allocation");
    Check(output.Ensure(NULL, device, 2560, 1440), "output allocation");
    HDC original = source.Acquire();
    SetPixel(original, 1, 1, RGB(17, 99, 201));
    SetPixel(original, 1919, 1079, RGB(255, 31, 5));
    MoveToEx(original, 7, 9, NULL);
    for (int frame = 0; frame < 400; ++frame) {
        Check(source.Ensure(NULL, device, 1920, 1080), "retained allocation");
        HDC dc = source.Acquire();
        Check(dc == original, "persistent handle");
        POINT point;
        GetCurrentPositionEx(dc, &point);
        Check(point.x == 0 && point.y == 0, "fresh drawing state");
        Check(GetPixel(dc, 1, 1) == RGB(17, 99, 201), "original fine detail retained");
        Check(GetPixel(dc, 1919, 1079) == RGB(255, 31, 5), "bottom-right retained");
        HDC target = output.Acquire();
        int previousMode = SetStretchBltMode(target, frame % 2 ? HALFTONE : COLORONCOLOR);
        POINT previousOrigin;
        Check(SetBrushOrgEx(target, 0, 0, &previousOrigin) != 0, "brush origin");
        Check(StretchBlt(target, 0, 0, 2560, 1440, dc, 0, 0, 1920, 1080, SRCCOPY) != 0, "presentation");
        SetStretchBltMode(target, previousMode);
        SetBrushOrgEx(target, previousOrigin.x, previousOrigin.y, NULL);
        Check(GetPixel(dc, 1, 1) == RGB(17, 99, 201), "filter leaves source unchanged");
        // Simulate damage/occlusion of output: it must never feed back into source.
        PatBlt(target, 0, 0, 2560, 1440, BLACKNESS);
        SetPixel(dc, 900, 400, RGB(frame % 256, 50, 70));
    }
    Check(GetPixel(source.Acquire(), 900, 400) == RGB(143, 50, 70), "partial updates retained");
    Check(source.Ensure(NULL, device, 1280, 720), "resolution change");
    Check(GetPixel(source.Acquire(), 1, 1) == RGB(0,0,0), "new surface cleared");
    Check(!source.Ensure(NULL, device, -1, 720) && !source.Ensure(NULL, device, 5000, 720), "invalid sizes");
    source.Reset(); output.Reset(); ReleaseDC(NULL, device);
    Check(GetGuiResources(GetCurrentProcess(), GR_GDIOBJECTS) <= handles, "no GDI handles leaked");
    puts("PASS 400 frames (200 nearest / 200 HALFTONE), source preservation, partial drawing, fresh DC state, resize, invalid sizes and GDI cleanup");
    return 0;
}
