@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars32.bat"
if errorlevel 1 exit /b 1
cd /d "%~dp0"
cl /nologo /MT /O2 /W4 /WX presenter-tests.cpp /Fe:presenter-tests.exe /link user32.lib gdi32.lib
if errorlevel 1 exit /b 1
presenter-tests.exe
exit /b %errorlevel%