#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <algorithm>
#include "source/dll/syncrash_surface.h"
int main() {
    HDC device = GetDC(NULL);
    SyncrashSurface source, output;
    if (!source.Ensure(NULL, device, 1920, 1080) || !output.Ensure(NULL, device, 2560, 1440)) return 1;
    HDC src = source.Acquire(), dst = output.Acquire();
    DIBSECTION dib = {};
    if (!GetObject(source.GetBitmap(), sizeof(dib), &dib) || !dib.dsBm.bmBits) return 2;
    DWORD *bits = static_cast<DWORD *>(dib.dsBm.bmBits);
    for (int y=0;y<1080;y++) for (int x=0;x<1920;x++) bits[y*1920+x] = RGB(x%256,y%256,(x^y)%256);
    LARGE_INTEGER freq; QueryPerformanceFrequency(&freq);
    puts("case,width,height,median_ms,p95_ms,samples");
    for (int test=0;test<4;test++) {
        int w = test<2 ? 2560 : 1920, h = test<2 ? 1440 : 1080;
        SetStretchBltMode(dst, test%2 ? HALFTONE : COLORONCOLOR); SetBrushOrgEx(dst,0,0,NULL);
        double samples[150];
        for(int i=-10;i<150;i++) {
            LARGE_INTEGER begin,end; GdiFlush(); QueryPerformanceCounter(&begin);
            if (!StretchBlt(dst,0,0,w,h,src,0,0,1920,1080,SRCCOPY)) return 3;
            GdiFlush(); QueryPerformanceCounter(&end);
            if(i>=0) samples[i]=(end.QuadPart-begin.QuadPart)*1000.0/freq.QuadPart;
        }
        std::sort(samples,samples+150);
        printf("%s,%d,%d,%.3f,%.3f,150\n",test%2 ? "HALFTONE" : "COLORONCOLOR",w,h,samples[75],samples[142]);
    }
    source.Reset();output.Reset();ReleaseDC(NULL,device);
    return 0;
}
