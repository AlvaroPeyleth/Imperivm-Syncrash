@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars32.bat"
if errorlevel 1 exit /b 1
cd /d "%~dp0"
cl /nologo /MT /O2 /W4 /WX surface-tests.cpp /Fe:surface-tests.exe /link user32.lib gdi32.lib
if errorlevel 1 exit /b 1
surface-tests.exe
exit /b %errorlevel%