#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <float.h>
#include <algorithm>
#include <vector>
#include "source/dll/syncrash_surface.h"
#include "source/dll/syncrash_presenter.h"
static void Check(bool ok,const char *message) { if(!ok){fprintf(stderr,"FAIL %s\n",message);fflush(stdout);ExitProcess(1);} }
int main() {
    HWND window=CreateWindowExW(WS_EX_TOOLWINDOW,L"STATIC",L"Syncrash offscreen rendering test",WS_POPUP,0,0,2560,1440,NULL,NULL,GetModuleHandle(NULL),NULL);
    Check(window!=NULL,"hidden test window");
    HDC dc=GetDC(window);
    SyncrashSurface source;
    SyncrashPresenter presenter;
    unsigned int fpuBefore,fpuAfter;
    _controlfp_s(&fpuBefore,0,0);
    Check(source.Ensure(window,dc,2,2),"test bitmap");
    HDC src=source.Acquire();
    SetPixel(src,0,0,RGB(0,0,0));SetPixel(src,1,0,RGB(255,0,0));
    SetPixel(src,0,1,RGB(0,255,0));SetPixel(src,1,1,RGB(255,255,255));
    bool created=presenter.Ensure(window,2,2,2,2);
    printf("Device creation HRESULT=%08lx\n",presenter.lastResult);
    Check(created,"1:1 device");
    DIBSECTION initial={};GetObject(source.GetBitmap(),sizeof(initial),&initial);
    printf("DIB width=%ld height=%ld infoheight=%ld bpp=%u\n",initial.dsBm.bmWidth,initial.dsBm.bmHeight,initial.dsBmih.biHeight,initial.dsBm.bmBitsPixel);
    Check(presenter.Draw(source.GetBitmap()),"1:1 drawing");
    DWORD pixels[9]={};
    Check(presenter.Readback(pixels,9),"1:1 readback");
    Check((pixels[0]&0xFFFFFF)==0 && (pixels[1]&0xFFFFFF)==0xFF0000 &&
        (pixels[2]&0xFFFFFF)==0x00FF00 && (pixels[3]&0xFFFFFF)==0xFFFFFF,"1:1 colors and alignment");
    Check(presenter.Ensure(window,2,2,3,3) && presenter.Draw(source.GetBitmap()),"filtered drawing");
    Check(presenter.Readback(pixels,9),"filtered readback");
    unsigned int red=(pixels[4]>>16)&255,green=(pixels[4]>>8)&255,blue=pixels[4]&255;
    Check(red>=127&&red<=128&&green>=127&&green<=128&&blue>=63&&blue<=64,"bilinear center");
    Check((pixels[0]&0xFFFFFF)==0 && (pixels[8]&0xFFFFFF)==0xFFFFFF,"clamped edges");
    Check(GetPixel(source.Acquire(),1,0)==RGB(255,0,0),"source preserved");
    Check(!presenter.Ensure(window,0,2,3,3) && !presenter.Ensure(window,2,2,9000,3),"invalid dimensions");
    _controlfp_s(&fpuAfter,0,0);Check(fpuBefore==fpuAfter,"game FPU state preserved");
    presenter.Reset();source.Reset();
    Check(source.Ensure(window,dc,1920,1080),"1080p bitmap");
    DIBSECTION dib={};GetObject(source.GetBitmap(),sizeof(dib),&dib);
    DWORD *bits=static_cast<DWORD *>(dib.dsBm.bmBits);
    for(int y=0;y<1080;y++)for(int x=0;x<1920;x++) bits[y*1920+x]=(DWORD)((x%256)<<16)|((y%256)<<8)|((x^y)%256);
    Check(presenter.Ensure(window,1920,1080,2560,1440),"1440p output");
    LARGE_INTEGER freq;QueryPerformanceFrequency(&freq);
    double samples[150];
    for(int i=-10;i<150;i++) {
        LARGE_INTEGER begin,end;QueryPerformanceCounter(&begin);
        Check(presenter.Draw(source.GetBitmap())&&presenter.Present(),"hardware upload/filter/present");
        QueryPerformanceCounter(&end);
        if(i>=0)samples[i]=(end.QuadPart-begin.QuadPart)*1000.0/freq.QuadPart;
    }
    std::sort(samples,samples+150);
    printf("GPU upload/filter/Present CPU wall time: median %.3f ms p95 %.3f ms (150 samples; hidden window, not game FPS)\n",samples[75],samples[142]);
    for(int i=0;i<6;i++) {
        presenter.Reset();
        Check(presenter.Ensure(window,1920,1080,i%2 ? 1920:2560,i%2 ?1080:1440)&&presenter.Draw(source.GetBitmap()),"recreation/resize");
    }
    presenter.Reset();source.Reset();ReleaseDC(window,dc);DestroyWindow(window);
    _controlfp_s(&fpuAfter,0,0);Check(fpuBefore==fpuAfter,"FPU state after cleanup");
    puts("PASS colors, 1:1 alignment, interpolation, clamped edges, source preservation, invalid sizes, recreation and FPU preservation");
    return 0;
}
