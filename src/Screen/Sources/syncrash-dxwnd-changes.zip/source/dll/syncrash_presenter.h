#pragma once
#include <windows.h>
#include <d3d9.h>
#include <string.h>

// Private trial: upload the retained 32bpp source, filter only on presentation.
// Windowed device, no display-mode changes, no changes to the game's FPU mode.
class SyncrashPresenter {
    IDirect3D9 *api;
    IDirect3DDevice9 *device;
    IDirect3DTexture9 *texture;
    HWND owner;
    DWORD thread;
    int sw, sh, dw, dh;
    HMODULE module;
    DWORD retryAt;
    struct Vertex { float x,y,z,rhw,u,v; };
public:
    HRESULT lastResult;
    SyncrashPresenter() : api(NULL),device(NULL),texture(NULL),owner(NULL),thread(0),
        sw(0),sh(0),dw(0),dh(0),module(NULL),retryAt(0),lastResult(S_OK) {}
    void Reset() {
        if (texture) texture->Release();
        if (device) device->Release();
        if (api) api->Release();
        texture=NULL;device=NULL;api=NULL;owner=NULL;thread=0;
        sw=sh=dw=dh=0;
        // Keep the system DLL loaded for the process lifetime, outside loader-lock cleanup.
    }
    bool Ensure(HWND window,int sourceWidth,int sourceHeight,int width,int height) {
        if(!window || sourceWidth<=0 || sourceHeight<=0 || width<=0 || height<=0 ||
            sourceWidth>4096 || sourceHeight>4096 || width>8192 || height>8192) return false;
        if(thread && thread!=GetCurrentThreadId()) return false;
        if(device && owner==window && sw==sourceWidth && sh==sourceHeight && dw==width && dh==height) {
            if(SUCCEEDED(device->TestCooperativeLevel())) return true;
            Reset(); retryAt=GetTickCount()+1000; return false;
        }
        if(retryAt && static_cast<LONG>(GetTickCount()-retryAt)<0) return false;
        Reset();
        if(!module) {
            WCHAR path[MAX_PATH];
            UINT length=GetSystemDirectoryW(path,MAX_PATH);
            if(!length || length+11>=MAX_PATH) return false;
            wcscat_s(path,L"\\d3d9.dll");
            module=LoadLibraryW(path);
        }
        typedef IDirect3D9 *(WINAPI *Create)(UINT);
        Create create=module ? reinterpret_cast<Create>(GetProcAddress(module,"Direct3DCreate9")) : NULL;
        if(!create || !(api=create(D3D_SDK_VERSION))) {lastResult=E_NOINTERFACE;return false;}
        D3DPRESENT_PARAMETERS pp={};
        pp.Windowed=TRUE;pp.SwapEffect=D3DSWAPEFFECT_DISCARD;pp.hDeviceWindow=window;
        pp.BackBufferWidth=width;pp.BackBufferHeight=height;pp.BackBufferFormat=D3DFMT_X8R8G8B8;
        pp.BackBufferCount=1;pp.PresentationInterval=D3DPRESENT_INTERVAL_IMMEDIATE;
        DWORD flags=D3DCREATE_SOFTWARE_VERTEXPROCESSING|D3DCREATE_MULTITHREADED|
            D3DCREATE_FPU_PRESERVE|D3DCREATE_NOWINDOWCHANGES;
        HRESULT hr=api->CreateDevice(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,window,flags,&pp,&device);
        lastResult=hr;
        if(SUCCEEDED(hr)) hr=device->CreateTexture(sourceWidth,sourceHeight,1,D3DUSAGE_DYNAMIC,
            D3DFMT_X8R8G8B8,D3DPOOL_DEFAULT,&texture,NULL);
        lastResult=hr;
        if(FAILED(hr)) { Reset();retryAt=GetTickCount()+1000;return false; }
        owner=window;thread=GetCurrentThreadId();sw=sourceWidth;sh=sourceHeight;dw=width;dh=height;
        device->SetRenderState(D3DRS_ZENABLE,FALSE);
        device->SetRenderState(D3DRS_LIGHTING,FALSE);
        device->SetRenderState(D3DRS_CULLMODE,D3DCULL_NONE);
        device->SetRenderState(D3DRS_ALPHABLENDENABLE,FALSE);
        device->SetSamplerState(0,D3DSAMP_MINFILTER,D3DTEXF_LINEAR);
        device->SetSamplerState(0,D3DSAMP_MAGFILTER,D3DTEXF_LINEAR);
        device->SetSamplerState(0,D3DSAMP_MIPFILTER,D3DTEXF_NONE);
        device->SetSamplerState(0,D3DSAMP_ADDRESSU,D3DTADDRESS_CLAMP);
        device->SetSamplerState(0,D3DSAMP_ADDRESSV,D3DTADDRESS_CLAMP);
        device->SetTextureStageState(0,D3DTSS_COLOROP,D3DTOP_SELECTARG1);
        device->SetTextureStageState(0,D3DTSS_COLORARG1,D3DTA_TEXTURE);
        device->SetTextureStageState(0,D3DTSS_ALPHAOP,D3DTOP_DISABLE);
        device->SetFVF(D3DFVF_XYZRHW|D3DFVF_TEX1);
        retryAt=0;return true;
    }
    bool Draw(HBITMAP bitmap) {
        if(!device || !texture || thread!=GetCurrentThreadId()) return false;
        DIBSECTION dib={};
        if(!GetObject(bitmap,sizeof(dib),&dib) || !dib.dsBm.bmBits || dib.dsBm.bmBitsPixel!=32 ||
            dib.dsBm.bmWidth!=sw || dib.dsBm.bmHeight!=sh || dib.dsBm.bmWidthBytes<sw*4) return false;
        // SyncrashSurface creates top-down storage; GetObject normalizes biHeight positive.
        // Complete any pending GDI writes before the CPU reads the DIB bits.
        GdiFlush();
        D3DLOCKED_RECT locked={};
        if(FAILED(texture->LockRect(0,&locked,NULL,D3DLOCK_DISCARD))) return false;
        for(int y=0;y<sh;y++) memcpy(static_cast<BYTE *>(locked.pBits)+y*locked.Pitch,
            static_cast<const BYTE *>(dib.dsBm.bmBits)+y*dib.dsBm.bmWidthBytes,sw*4);
        if(FAILED(texture->UnlockRect(0))) return false;
        Vertex vertices[4]={{-0.5f,-0.5f,0,1,0,0},{dw-0.5f,-0.5f,0,1,1,0},
            {-0.5f,dh-0.5f,0,1,0,1},{dw-0.5f,dh-0.5f,0,1,1,1}};
        if(FAILED(device->SetTexture(0,texture)) || FAILED(device->BeginScene())) return false;
        HRESULT result=device->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP,2,vertices,sizeof(Vertex));
        HRESULT end=device->EndScene();
        return SUCCEEDED(result) && SUCCEEDED(end);
    }
    bool Present() { return device && SUCCEEDED(device->Present(NULL,NULL,NULL,NULL)); }
    // Readback is for tests only; the game never copies output into the source.
    bool Readback(DWORD *pixels,int count) {
        if(!device || count<dw*dh) return false;
        IDirect3DSurface9 *back=NULL,*read=NULL;
        HRESULT hr=device->GetBackBuffer(0,0,D3DBACKBUFFER_TYPE_MONO,&back);
        if(SUCCEEDED(hr)) hr=device->CreateOffscreenPlainSurface(dw,dh,D3DFMT_X8R8G8B8,D3DPOOL_SYSTEMMEM,&read,NULL);
        if(SUCCEEDED(hr)) hr=device->GetRenderTargetData(back,read);
        D3DLOCKED_RECT locked={};
        if(SUCCEEDED(hr)) {
            hr=read->LockRect(&locked,NULL,D3DLOCK_READONLY);
            if(SUCCEEDED(hr)) {
                for(int y=0;y<dh;y++) memcpy(pixels+y*dw,static_cast<BYTE *>(locked.pBits)+y*locked.Pitch,dw*4);
                read->UnlockRect();
            }
        }
        if(read)read->Release();if(back)back->Release();
        return SUCCEEDED(hr);
    }
};
