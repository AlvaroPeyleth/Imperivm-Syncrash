#pragma once
#include <windows.h>

// Private Syncrash experiment: retain original pixels, never read back scaled output.
class SyncrashSurface {
    HDC dc;
    HBITMAP bitmap;
    HGDIOBJ previousBitmap;
    HWND owner;
    int width, height, saved;
public:
    SyncrashSurface() : dc(NULL), bitmap(NULL), previousBitmap(NULL), owner(NULL), width(0), height(0), saved(0) {}
    HDC GetDC() const { return dc; }
    HBITMAP GetBitmap() const { return bitmap; }
    void Reset() {
        if (dc && saved) RestoreDC(dc, saved);
        if (dc && previousBitmap) SelectObject(dc, previousBitmap);
        if (bitmap) DeleteObject(bitmap);
        if (dc) DeleteDC(dc);
        dc = NULL; bitmap = NULL; previousBitmap = NULL; owner = NULL;
        width = height = saved = 0;
    }
    bool Ensure(HWND window, HDC device, int w, int h) {
        if (w <= 0 || h <= 0 || w > 4096 || h > 4096) return false;
        if (dc && owner == window && width == w && height == h) return true;
        Reset();
        BITMAPINFO info = {};
        info.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        info.bmiHeader.biWidth = w;
        info.bmiHeader.biHeight = -h;
        info.bmiHeader.biPlanes = 1;
        info.bmiHeader.biBitCount = 32;
        info.bmiHeader.biCompression = BI_RGB;
        void *pixels = NULL;
        dc = CreateCompatibleDC(device);
        if (!dc) return false;
        bitmap = CreateDIBSection(device, &info, DIB_RGB_COLORS, &pixels, NULL, 0);
        if (!bitmap || !pixels) { Reset(); return false; }
        previousBitmap = SelectObject(dc, bitmap);
        if (!previousBitmap || previousBitmap == HGDI_ERROR) { previousBitmap = NULL; Reset(); return false; }
        ZeroMemory(pixels, static_cast<SIZE_T>(w) * h * 4);
        owner = window; width = w; height = h;
        return true;
    }
    HDC Acquire() {
        if (!dc) return NULL;
        // Restore default DC attributes without discarding the retained pixels.
        if (saved) RestoreDC(dc, saved);
        saved = SaveDC(dc);
        return saved ? dc : NULL;
    }
};
